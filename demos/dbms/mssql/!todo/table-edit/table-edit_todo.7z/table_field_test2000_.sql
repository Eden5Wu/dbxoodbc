CREATE TABLE [dbo].[table_field_test1] (
  [id] bigint NOT NULL,
  [f_binary] binary(300) NULL,
  [f_bit] bit NULL,
  [f_char_1] char(1) NULL,
  [f_char_3] char(3) NULL,
  [f_datetime] datetime NULL,
  [f_decimal_19_5] decimal(19, 5) NULL,
  [f_float] float NULL,
  [f_image] image NULL,
  [f_int] int NULL,
  [f_money] money NULL,
  [f_nchar_1] nchar(1) NULL,
  [f_nchar_3] nchar(3) NULL,
  [f_ntext] ntext NULL,
  [f_numeric_19_5] numeric(19, 5) NULL,
  [f_nvarchar] nvarchar(10) NULL,
  [f_real] real NULL,
  [f_smalldatetime] smalldatetime NULL,
  [f_smallint] smallint NULL,
  [f_smallmoney] smallmoney NULL,
  [f_sql_variant] sql_variant NULL,
  [f_sysname] sysname NULL,
  [f_text] text NULL,
  [f_timestamp] timestamp NULL,
  [f_tinyint] tinyint NULL,
  [f_uniqueidentifier] uniqueidentifier NULL,
  [f_varbinary] varbinary(300) NULL,
  [f_varchar] varchar(10) NULL
  --[f_xml] xml NULL, -- MSSQL 2005
  --[f_sysname_sys] [sys].[sysname] NULL, -- MSSQL 2005
  PRIMARY KEY CLUSTERED ([id])
)
GO
