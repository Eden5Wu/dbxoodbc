1) create database dbxoodbc
2) create user/login : name=user1; password=pwd1
