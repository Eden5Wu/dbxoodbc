drop PROCEDURE test_proc_refcursor_a;
/
drop PROCEDURE "Test_Proc_RefCursor_A"
/
drop PACKAGE pkg_test_dbxoodbc_01;
/
