exec my_proc @type=2;
select * from table1;
select * from table2;
select * from table3;
