select * from table1;
select * from table2;
select * from table3;
