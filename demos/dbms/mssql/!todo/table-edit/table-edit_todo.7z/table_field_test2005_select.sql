select * from dbx_test_short
select * from dbx_test_char
select * from dbx_test_varchar
select * from dbx_test_nchar
select * from dbx_test_nvarchar
select * from dbx_test_nchar2
select * from dbx_test_long
