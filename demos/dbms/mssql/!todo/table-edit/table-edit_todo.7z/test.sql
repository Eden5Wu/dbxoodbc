select count(*) FROM  sys.all_objects
