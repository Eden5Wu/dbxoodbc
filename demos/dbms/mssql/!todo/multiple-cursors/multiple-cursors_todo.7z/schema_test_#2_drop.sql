drop table table1;
drop table table2;
drop table table3;
drop procedure my_proc;
